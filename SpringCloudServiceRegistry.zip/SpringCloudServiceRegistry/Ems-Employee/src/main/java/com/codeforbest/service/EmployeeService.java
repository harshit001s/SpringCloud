package com.codeforbest.service;

import org.springframework.stereotype.Service;

import com.codeforbest.entity.Employee;

@Service
public interface EmployeeService {

	public Employee getEmployee(int id);
}
