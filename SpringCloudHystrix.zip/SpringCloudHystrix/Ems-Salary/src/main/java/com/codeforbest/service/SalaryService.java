package com.codeforbest.service;

import org.springframework.stereotype.Service;

import com.codeforbest.entity.Salary;

@Service
public interface SalaryService {

	public Salary getEmployeeSalary(int empId);
}
