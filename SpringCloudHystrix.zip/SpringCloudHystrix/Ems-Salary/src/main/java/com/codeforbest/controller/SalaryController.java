package com.codeforbest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.codeforbest.entity.Salary;
import com.codeforbest.service.SalaryService;

@RestController
public class SalaryController {

	@Autowired
	private SalaryService salaryService;
	
	@GetMapping(value="/salary/{empId}")
	public Salary getEmployeeSalary(@PathVariable("empId") Integer empId) {
		if(empId == 1)
			throw new RuntimeException();
		return salaryService.getEmployeeSalary(empId);
	}
}
