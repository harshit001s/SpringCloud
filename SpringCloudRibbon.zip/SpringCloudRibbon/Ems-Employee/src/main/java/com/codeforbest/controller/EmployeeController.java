package com.codeforbest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.codeforbest.entity.Employee;
import com.codeforbest.entity.Leave;
import com.codeforbest.entity.Salary;
import com.codeforbest.service.EmployeeService;

@RestController
@RibbonClient("empribbon")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping(value="/employee/{empId}")
	public Employee getEmployeeDetails(@PathVariable("empId") Integer empId) {
		
		Employee employee = employeeService.getEmployee(empId);
		Salary salary = new RestTemplate().getForObject("http://localhost:8081/salary/"+empId, Salary.class);
		Leave leave = new RestTemplate().getForObject("http://localhost:8084/leave/"+empId, Leave.class);
		employee.setSalary(salary);
		employee.setLeave(leave);
		
		return employee;
	}
	@GetMapping(value="/leave/{empId}")
	public Employee getEmployeeLeaves(@PathVariable("empId") Integer empId) {
		
		Employee employee = employeeService.getEmployee(empId);
		Leave leave = restTemplate.getForObject("http://empribbon/leave/"+empId, Leave.class);
		employee.setLeave(leave);
		
		return employee;
	}
}
