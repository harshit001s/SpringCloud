package com.codeforbest.entity;

public class Leave {

	private int id;
	private int empId;
	private int usedLeaves;
	private int unusedLeaves;
	private int totalLeaves;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getUsedLeaves() {
		return usedLeaves;
	}
	public void setUsedLeaves(int usedLeaves) {
		this.usedLeaves = usedLeaves;
	}
	public int getUnusedLeaves() {
		return unusedLeaves;
	}
	public void setUnusedLeaves(int unusedLeaves) {
		this.unusedLeaves = unusedLeaves;
	}
	public int getTotalLeaves() {
		return totalLeaves;
	}
	public void setTotalLeaves(int totalLeaves) {
		this.totalLeaves = totalLeaves;
	}
}
