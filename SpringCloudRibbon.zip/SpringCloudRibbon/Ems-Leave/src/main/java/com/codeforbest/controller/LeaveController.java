package com.codeforbest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.codeforbest.entity.Leave;
import com.codeforbest.service.LeaveService;

@RestController
public class LeaveController {

	@Autowired
	private LeaveService leaveService;
	
	@GetMapping(value="/leave/{empId}")
	public Leave getEmployeeLeave(@PathVariable("empId") Integer empId) {
		System.out.println("----Leave Application----");
		return leaveService.getEmployeeLeave(empId);
	}
	
}
