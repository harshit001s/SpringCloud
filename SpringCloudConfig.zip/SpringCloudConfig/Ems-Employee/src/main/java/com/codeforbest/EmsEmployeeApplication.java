package com.codeforbest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsEmployeeApplication.class, args);
	}
}
