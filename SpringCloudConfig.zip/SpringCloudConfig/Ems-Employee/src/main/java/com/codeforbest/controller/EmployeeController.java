package com.codeforbest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.codeforbest.entity.Employee;
import com.codeforbest.entity.Leave;
import com.codeforbest.entity.Salary;
import com.codeforbest.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping(value="/employee/{empId}")
	public Employee getEmployeeDetails(@PathVariable("empId") Integer empId) {
		
		Employee employee = employeeService.getEmployee(empId);
		Salary salary = new RestTemplate().getForObject("http://localhost:8081/salary/"+empId, Salary.class);
		Leave leave = new RestTemplate().getForObject("http://localhost:8084/leave/"+empId, Leave.class);
		employee.setSalary(salary);
		employee.setLeave(leave);
		
		return employee;
	}
	
}
