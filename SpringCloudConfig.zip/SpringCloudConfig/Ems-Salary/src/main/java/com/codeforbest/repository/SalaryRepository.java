package com.codeforbest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codeforbest.entity.Salary;

public interface SalaryRepository extends JpaRepository<Salary, Integer> {

	public Salary findByEmpId(int empId);
}
