package com.codeforbest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsSalaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsSalaryApplication.class, args);
	}
}
