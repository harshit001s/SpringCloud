package com.codeforbest.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.codeforbest.entity.Employee;
import com.codeforbest.entity.Leave;
import com.codeforbest.entity.Salary;
import com.codeforbest.service.EmployeeService;
import com.codeforbest.service.EmsSalaryService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private EmsSalaryService salaryService;
	
	@Autowired
	DiscoveryClient discoveryClient;
	
	@GetMapping(value="/employee/{empId}")
	public Employee getEmployeeDetails(@PathVariable("empId") Integer empId) {
		
		Employee employee = employeeService.getEmployee(empId);
		
		List<ServiceInstance> serviceSalaryInstances = discoveryClient.getInstances("EmsSalary");
		ServiceInstance serviceSalaryInstance = serviceSalaryInstances.get(0);
		URI salaryURI = serviceSalaryInstance.getUri();

		List<ServiceInstance> serviceLeaveInstances = discoveryClient.getInstances("EmsLeave");
		ServiceInstance serviceLeaveInstance = serviceLeaveInstances.get(0);
		URI leaveURI = serviceLeaveInstance.getUri();
		
		Salary salary = new RestTemplate().getForObject(salaryURI + "/salary/"+empId, Salary.class);
		Leave leave = new RestTemplate().getForObject(leaveURI+"/leave/"+empId, Leave.class);
		employee.setSalary(salary);
		employee.setLeave(leave);
		
		return employee;
	}
	@GetMapping(value="/salary/{empId}")
	public Employee getEmployeeSalary(@PathVariable("empId") Integer empId) {
		
		Employee employee = employeeService.getEmployee(empId);
		
		Salary salary = salaryService.getEmployeeSalary(empId);
		/*List<ServiceInstance> serviceSalaryInstances = discoveryClient.getInstances("EmsSalary");
		ServiceInstance serviceSalaryInstance = serviceSalaryInstances.get(0);
		URI  salaryURI= serviceSalaryInstance.getUri();
		System.out.println(salaryURI);
		Salary salary = new RestTemplate().getForObject(salaryURI + "/salary/"+empId, Salary.class);
		*/
		employee.setSalary(salary);
		
		return employee;
	}
	
}
