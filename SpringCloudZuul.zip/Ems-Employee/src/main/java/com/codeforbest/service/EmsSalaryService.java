package com.codeforbest.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.codeforbest.entity.Salary;

@FeignClient("EmsSalary")
public interface EmsSalaryService {

	@GetMapping("/salary/{empId}")
	public Salary getEmployeeSalary(@PathVariable("empId") Integer empId);
	
}
