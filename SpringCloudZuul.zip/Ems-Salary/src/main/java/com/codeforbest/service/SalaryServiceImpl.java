package com.codeforbest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeforbest.entity.Salary;
import com.codeforbest.repository.SalaryRepository;

@Service
public class SalaryServiceImpl implements SalaryService {

	@Autowired
	private SalaryRepository salaryRepository;
	
	@Override
	public Salary getEmployeeSalary(int empId) {
		return salaryRepository.findByEmpId(empId);
	}

}
