package com.codeforbest.service;

import org.springframework.stereotype.Service;

import com.codeforbest.entity.Leave;

@Service
public interface LeaveService {
	
	public Leave getEmployeeLeave(int empId);

}
