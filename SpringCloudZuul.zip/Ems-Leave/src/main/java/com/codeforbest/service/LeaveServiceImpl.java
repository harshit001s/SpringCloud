package com.codeforbest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeforbest.entity.Leave;
import com.codeforbest.repository.LeaveRepository;

@Service
public class LeaveServiceImpl implements LeaveService {
	
	@Autowired
	private LeaveRepository leaveRepository;

	@Override
	public Leave getEmployeeLeave(int empId) {		
		return leaveRepository.findByempId(empId);
	}

}
